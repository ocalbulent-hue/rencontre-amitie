-- Rencontre & Amitié — schéma initial PostgreSQL/Supabase
-- Exécuter dans Supabase > SQL Editor. À faire relire avant lancement public.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Membre' check (char_length(display_name) between 2 and 40),
  birth_date date,
  gender text check (gender in ('woman','man','nonbinary','prefer_not_to_say') or gender is null),
  bio text not null default '' check (char_length(bio) <= 500),
  city text not null default '' check (char_length(city) <= 80),
  interests text[] not null default '{}',
  is_visible boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create or replace function public.is_adult(d date)
returns boolean language sql immutable as $$
  select d is not null and d <= (current_date - interval '18 years')::date
$$;

create or replace function public.create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare bd date;
begin
  begin bd := nullif(new.raw_user_meta_data->>'birth_date','')::date;
  exception when others then bd := null;
  end;
  if bd is null or not public.is_adult(bd) then
    raise exception 'This service is only available to adults aged 18 or over';
  end if;
  insert into public.profiles(id,display_name,birth_date,gender)
  values (
    new.id,
    coalesce(nullif(left(new.raw_user_meta_data->>'display_name',40),''),'Membre'),
    bd,
    case when new.raw_user_meta_data->>'gender' in ('woman','man','nonbinary','prefer_not_to_say') then new.raw_user_meta_data->>'gender' else null end
  ) on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

create policy "members can view visible profiles" on public.profiles
for select to authenticated using (is_visible = true or id = auth.uid());
create policy "members can create their own profile" on public.profiles
for insert to authenticated with check (id = auth.uid() and (birth_date is null or public.is_adult(birth_date)));
create policy "members can update their own profile" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and (birth_date is null or public.is_adult(birth_date)));
create policy "members can delete their own profile" on public.profiles
for delete to authenticated using (id = auth.uid());

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now(),
  constraint no_self_message check (sender_id <> recipient_id)
);
create index if not exists messages_sender_created_idx on public.messages(sender_id, created_at desc);
create index if not exists messages_recipient_created_idx on public.messages(recipient_id, created_at desc);
alter table public.messages enable row level security;
create policy "participants can read their messages" on public.messages
for select to authenticated using (auth.uid() = sender_id or auth.uid() = recipient_id);
create policy "sender can send messages" on public.messages
for insert to authenticated with check (auth.uid() = sender_id and sender_id <> recipient_id and exists (select 1 from public.profiles p where p.id = recipient_id and p.is_visible = true));

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
alter table public.blocks enable row level security;
create policy "users can see their own blocks" on public.blocks
for select to authenticated using (auth.uid() = blocker_id);
create policy "users can block others" on public.blocks
for insert to authenticated with check (auth.uid() = blocker_id);
create policy "users can unblock others" on public.blocks
for delete to authenticated using (auth.uid() = blocker_id);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 100),
  details text not null default '' check (char_length(details) <= 2000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now(),
  check (reporter_id <> reported_id)
);
alter table public.reports enable row level security;
create policy "members can submit reports" on public.reports
for insert to authenticated with check (auth.uid() = reporter_id);
create policy "members can see their own reports" on public.reports
for select to authenticated using (auth.uid() = reporter_id);

-- Important: never expose the service-role key in browser code.
-- Add moderation workflows, retention/deletion jobs, rate limits and audit controls before public launch.


-- Privacy preferences and moderation/billing extensions
alter table public.profiles add column if not exists privacy_consent_at timestamptz;
alter table public.profiles add column if not exists terms_accepted_at timestamptz;
alter table public.profiles add column if not exists moderation_status text not null default 'active'
  check (moderation_status in ('active','limited','suspended'));
alter table public.profiles drop constraint if exists profiles_email_key;

-- Messages are limited to 20 inserts per user per 10 minutes; this is a baseline,
-- not a substitute for CAPTCHA, edge rate limiting, abuse monitoring and review.
create table if not exists public.message_rate_events (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.message_rate_events enable row level security;
revoke all on public.message_rate_events from anon, authenticated;

create or replace function public.enforce_message_rate_limit()
returns trigger language plpgsql security definer set search_path=public as $$
declare recent_count integer;
begin
  if exists(select 1 from public.profiles where id=new.sender_id and moderation_status <> 'active') then
    raise exception 'Account is restricted from sending messages';
  end if;
  if exists(select 1 from public.blocks b where
    (b.blocker_id=new.sender_id and b.blocked_id=new.recipient_id) or
    (b.blocker_id=new.recipient_id and b.blocked_id=new.sender_id)) then
    raise exception 'Messaging is unavailable for this pair';
  end if;
  select count(*) into recent_count from public.message_rate_events
   where user_id=new.sender_id and created_at > now()-interval '10 minutes';
  if recent_count >= 20 then raise exception 'Message rate limit exceeded'; end if;
  insert into public.message_rate_events(user_id) values(new.sender_id);
  return new;
end;
$$;
drop trigger if exists messages_rate_limit on public.messages;
create trigger messages_rate_limit before insert on public.messages
  for each row execute procedure public.enforce_message_rate_limit();

-- Hide profiles that are suspended and prevent messages to hidden/suspended users.
drop policy if exists "members can view visible profiles" on public.profiles;
create policy "members can view visible profiles" on public.profiles
  for select to authenticated using ((is_visible = true and moderation_status='active') or id = auth.uid());
drop policy if exists "sender can send messages" on public.messages;
create policy "sender can send messages" on public.messages
  for insert to authenticated with check (
    auth.uid() = sender_id and sender_id <> recipient_id
    and exists (select 1 from public.profiles p where p.id=recipient_id and p.is_visible=true and p.moderation_status='active')
    and not exists (select 1 from public.blocks b where
      (b.blocker_id=sender_id and b.blocked_id=recipient_id) or
      (b.blocker_id=recipient_id and b.blocked_id=sender_id))
  );

create table if not exists public.billing_customers (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_customer_id text unique not null,
  created_at timestamptz not null default now()
);
alter table public.billing_customers enable row level security;
revoke all on public.billing_customers from anon, authenticated;

create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_subscription_id text unique not null,
  stripe_customer_id text not null,
  status text not null,
  plan text,
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.subscriptions enable row level security;
create policy "members can view their own subscription" on public.subscriptions
  for select to authenticated using (auth.uid()=user_id);
revoke insert, update, delete on public.subscriptions from anon, authenticated;

-- Restrict reports: no one can change report status except the server-side admin client.
drop policy if exists "members can submit reports" on public.reports;
create policy "members can submit reports" on public.reports
  for insert to authenticated with check (
    auth.uid() = reporter_id and reporter_id <> reported_id
    and exists(select 1 from public.profiles p where p.id=reported_id)
  );


-- Vérification d'identité via un prestataire externe (aucune copie de pièce stockée ici).
create table if not exists public.identity_verifications (
  user_id uuid primary key references auth.users(id) on delete cascade,
  stripe_verification_session_id text unique,
  status text not null default 'unverified'
    check (status in ('unverified','pending','verified','requires_input','canceled')),
  verified_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.identity_verifications enable row level security;
drop policy if exists "Users can view own identity verification" on public.identity_verifications;
create policy "Users can view own identity verification"
  on public.identity_verifications for select to authenticated
  using (auth.uid() = user_id);
-- Écriture réservée au backend via la clé service_role; aucune politique INSERT/UPDATE publique.
