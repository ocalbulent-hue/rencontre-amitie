# Accès à la console de modération

Ne rendez jamais l'attribut admin modifiable depuis le navigateur.

Pour accorder l'accès, utilisez un environnement de confiance (script serveur privé utilisant `SUPABASE_SERVICE_ROLE_KEY`, ou une opération contrôlée dans l'outil d'administration Supabase) et définissez `app_metadata.role = "admin"` pour le compte choisi. Ne copiez pas la clé service role dans le dépôt ni dans un outil client. Exigez un MFA pour les administrateurs et vérifiez périodiquement la liste des comptes privilégiés.

La console `/moderation` permet de traiter les signalements enregistrés. Documentez les règles d'escalade, les preuves minimales à conserver, la confidentialité des personnes signalantes, les appels et la suppression/expiration des données.
