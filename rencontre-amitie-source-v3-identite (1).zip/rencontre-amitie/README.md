# Rencontre & Amitié — source de déploiement

Application Next.js + Supabase avec parcours d'inscription, profils, annuaire, messagerie, fonctions initiales de sécurité/modération, suppression de compte et intégration de paiement Stripe.

## Important : statut du projet
Le package est un socle fonctionnel à configurer, tester et faire auditer. Il ne constitue pas une garantie de conformité RGPD ni un service de rencontre prêt à être exploité publiquement. Les pages juridiques sont des modèles. Aucun prix n'est prédéfini et aucun paiement n'est activé avant configuration Stripe. Faites effectuer une revue de sécurité et juridique avant le lancement.

## Installation locale
Prérequis : Node.js 20+, un projet Supabase et (pour tester les paiements) un compte Stripe.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Renseignez `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY`. Dans Supabase > SQL Editor, exécutez `supabase/schema.sql`. Ouvrez http://localhost:3000.

## Déploiement
1. Importez le dossier dans GitHub et connectez le dépôt à Vercel ou un hébergeur Next.js.
2. Ajoutez les variables d'environnement de `.env.example`.
3. Dans Supabase Authentication > URL Configuration, configurez Site URL et les URL `/auth/callback` de développement et de production.
4. Configurez un fournisseur SMTP transactionnel pour la confirmation d'adresse.
5. Testez tous les parcours avec des comptes de test différents, y compris des tentatives d'accès non autorisées.

## Modération, blocage et signalement
- Les profils de membres comportent des actions « Bloquer » et « Signaler ».
- Les blocs sont réciproquement pris en compte dans l'annuaire et les insertions de messages.
- Les signalements apparaissent dans `/moderation` pour un compte dont `app_metadata.role` vaut `admin`.
- Le rôle admin doit être défini uniquement via une opération de confiance côté serveur/Supabase Admin API, jamais depuis le navigateur.
- La console peut prendre en charge, résoudre, classer sans suite ou masquer un profil.
- Complétez par une procédure de traitement, des délais, une politique d'escalade et un canal de contact d'urgence.

## Anti-spam
Un déclencheur SQL limite les envois à 20 messages par utilisateur sur 10 minutes et bloque les messages entre membres ayant un blocage actif. Ce seuil est une protection de base, pas une défense exhaustive. Ajoutez CAPTCHA/risk checks à l'inscription, limitation par IP et par compte au niveau edge/WAF, détection d'abus, alertes, journaux de sécurité avec conservation limitée et tests de charge. Ne journalisez pas inutilement le contenu des messages.

## Suppression de compte
La page `/compte` appelle un endpoint serveur qui supprime l'utilisateur Auth via la clé Supabase service role gardée exclusivement côté serveur. La suppression doit être testée sur une base de préproduction : les données liées par clés étrangères sont supprimées en cascade. Les données qui doivent légalement être conservées (par exemple certaines pièces comptables) doivent être séparées et faire l'objet d'une politique de conservation documentée. Fournissez également un canal alternatif pour les demandes si l'utilisateur ne peut pas se connecter.

## Abonnements Stripe
1. Dans Stripe, créez les produits/prix récurrents mensuel et annuel.
2. Ajoutez `STRIPE_SECRET_KEY`, `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_YEARLY`, `STRIPE_WEBHOOK_SECRET` et `NEXT_PUBLIC_SITE_URL` aux variables d'environnement.
3. Configurez dans Stripe un webhook vers `https://VOTRE-DOMAINE/api/stripe/webhook` avec les événements `checkout.session.completed`, `customer.subscription.updated` et `customer.subscription.deleted`.
4. Testez d'abord en mode test avec les cartes de test Stripe. N'utilisez les clés live qu'après vérifications légales et techniques.
5. Configurez le portail client Stripe pour que les membres puissent gérer ou résilier leur abonnement.
6. Définissez avant la vente le prix TTC, les avantages réellement fournis, la durée, le renouvellement, la résiliation, les remboursements et les mentions précontractuelles. Pour les consommateurs en France/UE, faites vérifier les obligations applicables (information précontractuelle, médiation, droit de rétractation et éventuelle demande d'exécution immédiate) par un juriste.

Le serveur ne fournit pas de fonctions premium réservées à un abonnement à ce stade : cette version prépare la facturation et la synchronisation du statut. Implémentez ensuite les contrôles d'accès premium côté serveur, jamais uniquement dans l'interface.

## Données personnelles et RGPD : liste de travail
Avant l'ouverture publique :
- Identifier l'éditeur et le responsable du traitement, leurs coordonnées et un contact de confidentialité.
- Définir les finalités et bases légales, les catégories de données, destinataires/sous-traitants, durées de conservation et transferts hors UE.
- Compléter la politique de confidentialité et les mentions légales, informer les membres des droits, et prévoir un processus de demande d'accès/rectification/effacement/opposition.
- Mettre en œuvre une procédure de suppression de compte et une politique de sauvegarde/expiration; expliquer les exceptions légales de conservation.
- Évaluer la nécessité d'une AIPD/DPIA, notamment si le traitement à grande échelle de données sensibles ou le profilage présente un risque élevé.
- Éviter de demander des données sensibles non nécessaires. Ne pas collecter d'informations sur l'orientation sexuelle sauf nécessité justifiée, base légale adaptée et protections renforcées.
- Configurer la région d'hébergement, les contrats de sous-traitance et les transferts internationaux avec Supabase, Stripe, l'hébergeur, l'e-mail et tout outil analytique.
- Définir consentement cookies si des traceurs non essentiels sont ajoutés; cette base n'ajoute pas de bannière de cookies car aucun outil de suivi publicitaire/analytique n'est inclus.
- Mettre en place des contrôles d'accès, MFA pour administrateurs, sauvegardes, gestion des incidents et procédure de notification des violations dans les délais applicables.
- Faire relire les CGU, politique de confidentialité, règles de modération, conditions d'abonnement et mentions légales par un professionnel qualifié.

## Variables d'environnement
Voir `.env.example`. `SUPABASE_SERVICE_ROLE_KEY`, clés Stripe secrètes et webhook secret doivent rester côté serveur, uniquement dans les variables d'environnement de l'hébergeur. Ne les commitez jamais.

## Pages principales
`/` accueil · `/inscription` · `/connexion` · `/membres` · `/profil` · `/messages` · `/compte` · `/abonnement` · `/moderation` (admin) · `/conditions` · `/confidentialite`.


## Vérification d’identité (Stripe Identity)

Une page `/verification-identite` permet à un membre connecté de lancer une session Stripe Identity. Le site conserve seulement le statut, la date de vérification et l’identifiant de session; il ne stocke pas de copie de pièce d’identité ni de selfie.

Configuration requise avant tout test :
1. Activer Stripe Identity dans le compte Stripe et utiliser d’abord les clés de test.
2. Exécuter de nouveau `supabase/schema.sql` dans l’éditeur SQL Supabase pour créer la table `identity_verifications` (ou exécuter uniquement son bloc final).
3. Dans Stripe, configurer l’URL webhook `https://VOTRE-DOMAINE/api/stripe/webhook` et écouter `identity.verification_session.verified`, `identity.verification_session.requires_input` et `identity.verification_session.canceled`, en plus des événements d’abonnement déjà utilisés.
4. Renseigner `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` et `NEXT_PUBLIC_SITE_URL` dans l’environnement du serveur.
5. Tester les parcours réussite, échec, annulation, reprise, suppression de compte et webhook avant le lancement.

Important : ne jamais demander aux membres d’envoyer une pièce d’identité par e-mail ou via un formulaire maison. Vérifiez les conditions, tarifs, disponibilité et règles de conservation de Stripe Identity pour votre pays. Mettez à jour la politique de confidentialité et réalisez une analyse RGPD adaptée avant lancement; les données d’identité sont sensibles. Le statut « vérifié » ne doit pas être présenté comme une garantie absolue de sécurité. À ce stade, la vérification est affichée dans l’espace compte mais n’est pas encore imposée pour envoyer des messages, afficher un badge public ou accéder à certaines fonctionnalités.
