import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ModerationActions from "./moderation-actions";
export default async function ModerationPage(){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect("/connexion");
 // Set user.app_metadata.role = "admin" using trusted server-side tooling only.
 if(user.app_metadata?.role!=="admin")redirect("/membres");
 const {data:reports}=await supabase.from("reports").select("id,reporter_id,reported_id,reason,details,status,created_at").order("created_at",{ascending:false}).limit(100);
 return <main className="legal-page"><Link href="/membres">← Retour aux membres</Link><h1>Console de modération</h1><p>Accessible uniquement aux comptes dont le rôle admin est défini côté serveur. Les signalements sont confidentiels.</p>{!reports?.length?<p>Aucun signalement en attente.</p>:reports.map((r:any)=><article className="moderation-item" key={r.id}><div><strong>{r.reason.replaceAll("_"," ")}</strong><span className="status-label">{r.status}</span></div><p>{r.details||"Aucun détail complémentaire."}</p><small>Signalant : {r.reporter_id} · Profil signalé : {r.reported_id} · {new Date(r.created_at).toLocaleString("fr-FR")}</small><ModerationActions reportId={r.id} reportedId={r.reported_id} status={r.status}/></article>)}</main>;
}
