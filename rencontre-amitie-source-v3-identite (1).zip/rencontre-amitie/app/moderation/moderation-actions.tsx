"use client";
import { useState } from "react";
export default function ModerationActions({reportId,reportedId,status}:{reportId:string;reportedId:string;status:string}){
 const [busy,setBusy]=useState(false);const [note,setNote]=useState("");
 async function act(action:"reviewing"|"resolved"|"dismissed"|"hide_profile"){
  setBusy(true);setNote("");const r=await fetch("/api/moderation/action",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({reportId,reportedId,action})});const d=await r.json().catch(()=>({}));setNote(r.ok?"Action enregistrée.":"Action refusée ou impossible.");setBusy(false);if(r.ok)window.location.reload();
 }
 return <div className="moderation-actions"><button disabled={busy||status==="reviewing"} onClick={()=>act("reviewing")}>Prendre en charge</button><button disabled={busy} onClick={()=>act("resolved")}>Résolu</button><button disabled={busy} onClick={()=>act("dismissed")}>Classer sans suite</button><button disabled={busy} onClick={()=>{if(confirm("Masquer ce profil de l’annuaire ?"))act("hide_profile")}}>Masquer le profil</button>{note&&<small>{note}</small>}</div>;
}
