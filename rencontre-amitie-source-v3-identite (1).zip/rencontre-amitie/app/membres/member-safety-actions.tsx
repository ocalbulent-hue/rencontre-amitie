"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
export default function MemberSafetyActions({ memberId, memberName }: { memberId: string; memberName: string }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("harassment");
  const [details, setDetails] = useState("");
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  async function block() {
    if (!confirm(`Bloquer ${memberName} ? Ses profils et messages ne devraient plus être accessibles dans votre expérience.`)) return;
    setBusy(true); setStatus("");
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setStatus("Reconnectez-vous pour continuer."); setBusy(false); return; }
    const { error } = await supabase.from("blocks").upsert({ blocker_id: user.id, blocked_id: memberId }, { onConflict: "blocker_id,blocked_id" });
    setStatus(error ? "Blocage impossible pour le moment." : "Membre bloqué.");
    setBusy(false);
  }
  async function report(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setStatus("");
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setStatus("Reconnectez-vous pour continuer."); setBusy(false); return; }
    const { error } = await supabase.from("reports").insert({ reporter_id: user.id, reported_id: memberId, reason, details });
    setStatus(error ? "Signalement impossible pour le moment." : "Signalement transmis à l’équipe de modération.");
    setOpen(false); setBusy(false);
  }
  return <div className="safety-actions"><div className="safety-buttons"><button className="quiet-button" onClick={block} disabled={busy}>Bloquer</button><button className="quiet-button" onClick={() => setOpen(!open)} disabled={busy}>Signaler</button></div>
    {open && <form className="report-form" onSubmit={report}><label>Motif<select value={reason} onChange={e=>setReason(e.target.value)}><option value="harassment">Harcèlement ou menace</option><option value="fake_profile">Faux profil / usurpation</option><option value="spam">Spam ou fraude</option><option value="inappropriate_content">Contenu inapproprié</option><option value="underage">Suspicion de personne mineure</option><option value="other">Autre motif</option></select></label><label>Détails facultatifs<textarea value={details} onChange={e=>setDetails(e.target.value)} maxLength={2000} rows={3} placeholder="Décrivez les faits sans inclure de données sensibles."/></label><button className="button primary" disabled={busy}>Envoyer le signalement</button></form>}
    {status && <p className="safety-status" role="status">{status}</p>}
  </div>;
}
