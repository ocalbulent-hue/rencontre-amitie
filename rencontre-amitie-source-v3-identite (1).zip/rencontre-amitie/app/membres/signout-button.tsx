"use client";
import { LogOut } from "lucide-react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
export default function SignOutButton() {
  const router = useRouter();
  async function signOut() { const supabase = createClient(); await supabase.auth.signOut(); router.push("/"); router.refresh(); }
  return <button className="quiet-button" onClick={signOut}><LogOut size={16}/> Déconnexion</button>;
}
