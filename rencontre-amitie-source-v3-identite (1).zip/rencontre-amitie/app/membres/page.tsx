import Link from "next/link";
import { redirect } from "next/navigation";
import { Heart, LogOut, Search, ShieldAlert, UserRound } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import SignOutButton from "./signout-button";
import MemberSafetyActions from "./member-safety-actions";
export default async function MembersPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");
  const { data: profile } = await supabase.from("profiles").select("display_name, bio, city, interests, gender").eq("id", user.id).maybeSingle();
  const { data: blocks } = await supabase.from("blocks").select("blocked_id").eq("blocker_id", user.id);
  const { data: blockedBy } = await supabase.from("blocks").select("blocker_id").eq("blocked_id", user.id);
  const excluded = new Set([user.id, ...(blocks || []).map((b:any)=>b.blocked_id), ...(blockedBy || []).map((b:any)=>b.blocker_id)]);
  const { data: allMembers } = await supabase.from("profiles").select("id, display_name, bio, city, interests, gender").eq("is_visible", true).limit(100);
  const members = (allMembers || []).filter((m:any)=>!excluded.has(m.id)).slice(0,24);
  return <main className="members-shell"><header className="topbar"><Link className="brand" href="/"><span className="brand-mark"><Heart size={20} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link><div className="member-nav"><Link href="/profil"><UserRound size={17}/> Mon profil</Link><Link href="/abonnement">Abonnement</Link><Link href="/compte">Mon compte</Link><SignOutButton/></div></header>
    <section className="members-intro"><span className="eyebrow">VOTRE ESPACE RENCONTRE</span><h1>Bonjour{profile?.display_name ? `, ${profile.display_name}` : ""}.</h1><p>Découvrez des profils et faites le premier pas, à votre rythme.</p><Link className="button primary" href="/profil"><UserRound size={17}/> Compléter mon profil</Link></section>
    <section className="directory"><div className="directory-head"><div><h2>Des personnes à découvrir</h2><p>Les profils visibles apparaissent ici.</p></div><span className="directory-icon"><Search/></span></div>
      {!members?.length ? <div className="empty-state"><Heart size={34}/><h3>Les rencontres commencent ici</h3><p>Il n’y a pas encore de profils à afficher. Complétez votre profil et revenez bientôt.</p></div> :
      <div className="member-grid">{members.map((m) => <article className="person-card" key={m.id}><div className="avatar"><UserRound size={30}/></div><div className="person-copy"><h3>{m.display_name || "Membre"}</h3><p className="person-city">{m.city || "Ville non renseignée"}</p><p>{m.bio || "Ce membre n’a pas encore ajouté de présentation."}</p>{m.interests?.length ? <div className="chips">{m.interests.slice(0,3).map((i: string)=><span key={i}>{i}</span>)}</div> : null}</div><Link className="text-link" href={`/messages?to=${m.id}`}>Faire connaissance →</Link><MemberSafetyActions memberId={m.id} memberName={m.display_name || "ce membre"}/></article>)}</div>}
    </section><footer><p>Respect, consentement et sécurité sont essentiels. <Link href="/confidentialite">En savoir plus</Link></p><SignOutButton/></footer>
  </main>;
}
