import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Rencontre & Amitié — Faites une belle rencontre",
  description: "Un espace de rencontre et d'amitié pour les adultes de 18 ans et plus."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fr"><body>{children}</body></html>;
}
