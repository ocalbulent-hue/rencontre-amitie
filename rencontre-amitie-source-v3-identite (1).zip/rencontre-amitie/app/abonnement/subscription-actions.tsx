"use client";
import { useState } from "react";
export default function SubscriptionActions({plan}:{plan:"monthly"|"yearly"}){
 const [busy,setBusy]=useState(false);const [error,setError]=useState("");
 async function start(){setBusy(true);setError("");const r=await fetch("/api/stripe/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({plan})});const d=await r.json().catch(()=>({}));if(r.ok&&d.url){window.location.href=d.url;return;}setError(d.error||"Paiement indisponible. Réessayez plus tard.");setBusy(false);}
 async function portal(){setBusy(true);setError("");const r=await fetch("/api/stripe/portal",{method:"POST"});const d=await r.json().catch(()=>({}));if(r.ok&&d.url){window.location.href=d.url;return;}setError(d.error||"Portail de facturation indisponible.");setBusy(false);}
 return <div className="subscription-actions"><button className="button primary full" onClick={start} disabled={busy}>{busy?"Redirection…":"Choisir cette formule"}</button><button className="quiet-button" onClick={portal} disabled={busy}>Gérer ou résilier un abonnement</button>{error&&<p className="form-error">{error}</p>}</div>;
}
