import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, Check, Heart } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import SubscriptionActions from "./subscription-actions";
export default async function SubscriptionPage(){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect("/connexion");
 const {data:sub}=await supabase.from("subscriptions").select("status,plan,current_period_end").eq("user_id",user.id).maybeSingle();
 return <main className="auth-shell"><Link className="back-link" href="/membres"><ArrowLeft size={16}/> Retour aux membres</Link><div className="auth-card"><Link href="/" className="brand auth-brand"><span className="brand-mark"><Heart size={20} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link><span className="eyebrow">ALLEZ PLUS LOIN DANS VOS RENCONTRES</span><h1>Votre abonnement</h1><p className="auth-intro">Choisissez une formule si vous souhaitez soutenir le service et accéder aux options premium qui seront activées progressivement.</p>
 {sub&&<div className="form-notice">Statut : {sub.status} · Formule : {sub.plan||"non renseignée"}{sub.current_period_end?` · Fin de période : ${new Date(sub.current_period_end).toLocaleDateString("fr-FR")}`:""}</div>}
 <div className="plan-card"><div><span className="plan-label">ESSENTIEL</span><h2>Mensuel</h2><p>Accès premium facturé chaque mois.</p></div><div className="plan-price">Prix défini dans Stripe<small>renouvellement automatique</small></div><ul><li><Check size={16}/> Soutenir le service</li><li><Check size={16}/> Gestion du paiement en ligne</li></ul><SubscriptionActions plan="monthly"/></div>
 <div className="plan-card"><div><span className="plan-label">FLEXIBLE</span><h2>Annuel</h2><p>Une facturation annuelle si cette option est activée.</p></div><div className="plan-price">Prix défini dans Stripe<small>renouvellement automatique</small></div><ul><li><Check size={16}/> Soutenir le service</li><li><Check size={16}/> Gestion du paiement en ligne</li></ul><SubscriptionActions plan="yearly"/></div>
 <p className="legal-small">Les tarifs, taxes, renouvellements, modalités de résiliation et avantages doivent être définis clairement avant publication. Aucun paiement n’est possible tant que les clés et identifiants de prix Stripe ne sont pas configurés.</p>
 </div></main>;
}
