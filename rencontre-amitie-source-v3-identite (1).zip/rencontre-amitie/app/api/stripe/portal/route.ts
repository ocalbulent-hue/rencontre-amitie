import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
export async function POST(){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Authentification requise."},{status:401});
 if(!process.env.STRIPE_SECRET_KEY)return NextResponse.json({error:"Stripe n’est pas configuré."},{status:503});
 try{
  const admin=createAdminClient();const {data}=await admin.from("billing_customers").select("stripe_customer_id").eq("user_id",user.id).maybeSingle();
  if(!data?.stripe_customer_id)return NextResponse.json({error:"Aucun compte de facturation n’est associé."},{status:404});
  const stripe=new Stripe(process.env.STRIPE_SECRET_KEY);
  const session=await stripe.billingPortal.sessions.create({customer:data.stripe_customer_id,return_url:`${process.env.NEXT_PUBLIC_SITE_URL}/abonnement`});
  return NextResponse.json({url:session.url});
 }catch(e){console.error("Stripe portal error",e instanceof Error?e.message:"unknown");return NextResponse.json({error:"Impossible d’ouvrir le portail de facturation."},{status:500});}
}
