import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
export async function POST(req:Request){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();
 if(!user)return NextResponse.json({error:"Authentification requise."},{status:401});
 const body=await req.json().catch(()=>({}));const plan=body.plan;
 const priceId=plan==="monthly"?process.env.STRIPE_PRICE_MONTHLY:plan==="yearly"?process.env.STRIPE_PRICE_YEARLY:null;
 if(!process.env.STRIPE_SECRET_KEY||!priceId||priceId.includes("replace"))return NextResponse.json({error:"Les abonnements ne sont pas encore configurés par l’administrateur."},{status:503});
 try{
  const stripe=new Stripe(process.env.STRIPE_SECRET_KEY);
  const admin=createAdminClient();
  const {data:profile}=await admin.from("billing_customers").select("stripe_customer_id").eq("user_id",user.id).maybeSingle();
  let customer=profile?.stripe_customer_id;
  if(!customer){
   const c=await stripe.customers.create({email:user.email,metadata:{supabase_user_id:user.id}});
   customer=c.id;
   await admin.from("billing_customers").upsert({user_id:user.id,stripe_customer_id:customer});
  }
  const session=await stripe.checkout.sessions.create({mode:"subscription",customer, line_items:[{price:priceId,quantity:1}],allow_promotion_codes:true,success_url:`${process.env.NEXT_PUBLIC_SITE_URL}/abonnement?success=1`,cancel_url:`${process.env.NEXT_PUBLIC_SITE_URL}/abonnement?cancelled=1`,metadata:{supabase_user_id:user.id,plan}});
  return NextResponse.json({url:session.url});
 }catch(e){console.error("Stripe checkout error",e instanceof Error?e.message:"unknown");return NextResponse.json({error:"Impossible de créer la session de paiement."},{status:500});}
}
