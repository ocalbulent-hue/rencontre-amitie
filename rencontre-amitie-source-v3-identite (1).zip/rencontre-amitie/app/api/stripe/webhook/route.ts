import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createAdminClient } from "@/lib/supabase/admin";
export async function POST(req:Request){
 const secret=process.env.STRIPE_WEBHOOK_SECRET;
 if(!secret||!process.env.STRIPE_SECRET_KEY)return NextResponse.json({error:"Webhook not configured"},{status:503});
 const signature=req.headers.get("stripe-signature");if(!signature)return NextResponse.json({error:"Missing signature"},{status:400});
 const raw=await req.text();
 let event:Stripe.Event;
 const stripe=new Stripe(process.env.STRIPE_SECRET_KEY);
 try{event=stripe.webhooks.constructEvent(raw,signature,secret);}catch{return NextResponse.json({error:"Invalid signature"},{status:400});}
 try{
  const admin=createAdminClient();
  if(event.type==="checkout.session.completed"){
   const s=event.data.object as Stripe.Checkout.Session;
   const userId=s.metadata?.supabase_user_id;const customerId=typeof s.customer==="string"?s.customer:null;const subscriptionId=typeof s.subscription==="string"?s.subscription:null;
   if(userId&&customerId)await admin.from("billing_customers").upsert({user_id:userId,stripe_customer_id:customerId});
   if(userId&&subscriptionId){
    const sub=await stripe.subscriptions.retrieve(subscriptionId);
    await admin.from("subscriptions").upsert({user_id:userId,stripe_subscription_id:sub.id,stripe_customer_id:customerId,status:sub.status,plan:s.metadata?.plan||"unknown",current_period_end:new Date(sub.current_period_end*1000).toISOString()},{onConflict:"user_id"});
   }
  }else if(event.type==="customer.subscription.updated"||event.type==="customer.subscription.deleted"){
   const sub=event.data.object as Stripe.Subscription;const customerId=typeof sub.customer==="string"?sub.customer:null;
   if(customerId){
    const {data:c}=await admin.from("billing_customers").select("user_id").eq("stripe_customer_id",customerId).maybeSingle();
    if(c?.user_id)await admin.from("subscriptions").upsert({user_id:c.user_id,stripe_subscription_id:sub.id,stripe_customer_id:customerId,status:sub.status,current_period_end:new Date(sub.current_period_end*1000).toISOString()},{onConflict:"user_id"});
   }
  }else if(event.type==="identity.verification_session.verified"||event.type==="identity.verification_session.requires_input"||event.type==="identity.verification_session.canceled"){
   const session=event.data.object as Stripe.Identity.VerificationSession;
   const userId=session.metadata?.supabase_user_id;
   if(userId){
    const status=session.status==="verified"?"verified":session.status==="requires_input"?"requires_input":session.status==="canceled"?"canceled":"pending";
    await admin.from("identity_verifications").upsert({
     user_id:userId,
     stripe_verification_session_id:session.id,
     status,
     verified_at:status==="verified"?new Date().toISOString():null,
     updated_at:new Date().toISOString()
    },{onConflict:"user_id"});
   }
  }
  return NextResponse.json({received:true});
 }catch(e){console.error("Stripe webhook processing error",e instanceof Error?e.message:"unknown");return NextResponse.json({error:"Webhook processing failed"},{status:500});}
}
