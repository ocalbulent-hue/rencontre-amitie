import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Connectez-vous pour vérifier votre identité." }, { status: 401 });
  if (!process.env.STRIPE_SECRET_KEY || !process.env.NEXT_PUBLIC_SITE_URL) {
    return NextResponse.json({ error: "La vérification d’identité n’est pas encore configurée." }, { status: 503 });
  }

  try {
    const admin = createAdminClient();
    const { data: current } = await admin.from("identity_verifications")
      .select("status").eq("user_id", user.id).maybeSingle();
    if (current?.status === "verified") {
      return NextResponse.json({ error: "Votre identité est déjà vérifiée." }, { status: 409 });
    }

    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.identity.verificationSessions.create({
      type: "document",
      return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/verification-identite?retour=1`,
      metadata: { supabase_user_id: user.id },
      options: { document: { require_matching_selfie: true } }
    });
    await admin.from("identity_verifications").upsert({
      user_id: user.id,
      stripe_verification_session_id: session.id,
      status: session.status === "verified" ? "verified" : "pending",
      verified_at: session.status === "verified" ? new Date().toISOString() : null,
      updated_at: new Date().toISOString()
    }, { onConflict: "user_id" });
    if (!session.url) return NextResponse.json({ error: "Le prestataire n’a pas fourni de lien de vérification." }, { status: 502 });
    return NextResponse.json({ url: session.url });
  } catch (error) {
    console.error("Identity session creation failed", error instanceof Error ? error.message : "unknown");
    return NextResponse.json({ error: "Impossible de démarrer la vérification pour le moment." }, { status: 500 });
  }
}
