import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
export async function POST() {
 const supabase=await createClient();
 const {data:{user},error}=await supabase.auth.getUser();
 if(error||!user)return NextResponse.json({error:"Authentification requise."},{status:401});
 try {
  const admin=createAdminClient();
  // Deleting auth.users cascades to the user's profile and related records via foreign keys.
  const {error:deleteError}=await admin.auth.admin.deleteUser(user.id);
  if(deleteError)throw deleteError;
  await supabase.auth.signOut();
  return NextResponse.json({ok:true});
 } catch(e) {
  console.error("Account deletion failed", e instanceof Error ? e.message : "unknown");
  return NextResponse.json({error:"La suppression n’a pas abouti. Réessayez ou contactez le support."},{status:500});
 }
}
