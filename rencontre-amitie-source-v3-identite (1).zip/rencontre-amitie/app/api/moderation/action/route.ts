import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
export async function POST(req:Request){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();
 if(!user||user.app_metadata?.role!=="admin")return NextResponse.json({error:"Accès interdit"},{status:403});
 const body=await req.json().catch(()=>({}));const {reportId,reportedId,action}=body;
 if(!reportId||!["reviewing","resolved","dismissed","hide_profile"].includes(action))return NextResponse.json({error:"Action invalide"},{status:400});
 const admin=createAdminClient();
 if(action==="hide_profile"){
  const {error}=await admin.from("profiles").update({is_visible:false}).eq("id",reportedId);
  if(error)return NextResponse.json({error:"Update failed"},{status:500});
  await admin.from("reports").update({status:"reviewing"}).eq("id",reportId);
 }else{
  const {error}=await admin.from("reports").update({status:action}).eq("id",reportId);
  if(error)return NextResponse.json({error:"Update failed"},{status:500});
 }
 return NextResponse.json({ok:true});
}
