import Link from "next/link";
import { redirect } from "next/navigation";
import { Heart, MessageCircle, ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import MessageComposer from "./message-composer";
export default async function MessagesPage({searchParams}:{searchParams:{to?:string}}) {
 const params=searchParams;const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect("/connexion");
 const target=params.to;
 let recipient:any=null;
 if(target){const {data}=await supabase.from("profiles").select("id,display_name").eq("id",target).maybeSingle();recipient=data;}
 const {data:messages}=await supabase.from("messages").select("id,sender_id,recipient_id,body,created_at").or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`).order("created_at",{ascending:true}).limit(100);
 return <main className="auth-shell"><Link className="back-link" href="/membres"><ArrowLeft size={16}/> Retour aux membres</Link><div className="auth-card messages-card"><Link href="/" className="brand auth-brand"><span className="brand-mark"><Heart size={20} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link><span className="eyebrow">PRENEZ LE TEMPS DE VOUS CONNAÎTRE</span><h1><MessageCircle size={25}/> Messages</h1>
 {target&&recipient?<><p className="auth-intro">Votre conversation avec {recipient.display_name||"ce membre"}.</p><MessageComposer recipientId={recipient.id}/></>:<p className="auth-intro">Pour commencer une conversation, ouvrez un profil depuis l’annuaire des membres.</p>}
 <div className="message-list">{messages?.map((m:any)=><article className={`message-bubble ${m.sender_id===user.id?"mine":"theirs"}`} key={m.id}><p>{m.body}</p><small>{new Date(m.created_at).toLocaleString("fr-FR")}</small></article>)}</div>
 <p className="safety-note">Ne partagez pas d’informations sensibles avec des personnes que vous ne connaissez pas. Vous pouvez bloquer ou signaler un membre depuis son profil.</p></div></main>;
}
