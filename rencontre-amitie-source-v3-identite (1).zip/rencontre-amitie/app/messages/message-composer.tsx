"use client";
import { FormEvent,useState } from "react";
import { createClient } from "@/lib/supabase/client";
export default function MessageComposer({recipientId}:{recipientId:string}) {
 const [body,setBody]=useState("");const [error,setError]=useState("");const [busy,setBusy]=useState(false);
 async function send(e:FormEvent<HTMLFormElement>){e.preventDefault();setError("");const text=body.trim();if(!text)return;if(text.length>2000){setError("Le message doit faire 2 000 caractères maximum.");return;}setBusy(true);const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user){setError("Reconnectez-vous pour envoyer un message.");setBusy(false);return;}const {error:err}=await supabase.from("messages").insert({sender_id:user.id,recipient_id:recipientId,body:text});if(err)setError("Message non envoyé. Vérifiez que le destinataire existe et réessayez.");else {setBody("");window.location.reload();}setBusy(false);}
 return <form onSubmit={send} className="composer"><label>Votre message<textarea rows={3} maxLength={2000} required value={body} onChange={e=>setBody(e.target.value)} placeholder="Bonjour, j’aimerais faire connaissance…"/></label>{error&&<p className="form-error">{error}</p>}<button className="button primary full" disabled={busy}>{busy?"Envoi…":"Envoyer le message"}</button></form>;
}
