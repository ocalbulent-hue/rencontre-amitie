import Link from "next/link";
import { Heart, ShieldCheck, MessageCircle, Sparkles, ArrowRight } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return (
    <main>
      <header className="topbar">
        <Link className="brand" href="/"><span className="brand-mark"><Heart size={21} fill="currentColor" /></span> Rencontre <em>&</em> Amitié</Link>
        <nav><a href="#concept">Le concept</a><a href="#securite">Notre engagement</a>
          {user ? <Link className="nav-cta" href="/membres">Accéder aux membres <ArrowRight size={16}/></Link> : <Link className="nav-cta" href="/connexion">Se connecter</Link>}
        </nav>
      </header>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><Sparkles size={15}/> DE BELLES HISTOIRES COMMENCENT ICI</span>
          <h1>Une rencontre.<br/><span>Un sourire.</span><br/>Et peut-être plus.</h1>
          <p className="hero-lede">Un espace bienveillant pour faire connaissance, échanger et laisser les belles histoires prendre leur temps.</p>
          <div className="hero-actions"><Link className="button primary" href="/inscription">Créer mon profil <ArrowRight size={18}/></Link><Link className="button secondary" href="/connexion">J’ai déjà un compte</Link></div>
          <p className="age-note"><ShieldCheck size={16}/> Réservé aux personnes de 18 ans et plus</p>
        </div>
        <div className="hero-art" role="img" aria-label="Illustration romantique de cœurs et de fleurs">
          <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <div className="heart-art"><Heart size={104} strokeWidth={1.1} fill="currentColor"/></div>
          <span className="float-heart fh1"><Heart size={28} fill="currentColor"/></span><span className="float-heart fh2"><Heart size={17} fill="currentColor"/></span>
          <div className="art-caption"><span className="caption-dot"></span><div><strong>Les plus belles rencontres</strong><small>commencent par une conversation.</small></div></div>
        </div>
      </section>
      <section className="features" id="concept">
        <div className="section-heading"><span className="eyebrow">UN ESPACE QUI VOUS RESSEMBLE</span><h2>Faites connaissance, à votre rythme.</h2><p>Les outils essentiels pour passer du premier regard à une vraie conversation.</p></div>
        <div className="feature-grid">
          <article className="feature-card"><span className="feature-icon pink"><Heart/></span><h3>Des profils authentiques</h3><p>Présentez-vous, partagez vos centres d’intérêt et découvrez d’autres personnes majeures.</p></article>
          <article className="feature-card"><span className="feature-icon rose"><MessageCircle/></span><h3>Des échanges simples</h3><p>Envoyez des messages et prenez le temps de faire connaissance dans un espace dédié.</p></article>
          <article className="feature-card" id="securite"><span className="feature-icon wine"><ShieldCheck/></span><h3>La sécurité d’abord</h3><p>Des outils de blocage et de signalement vous aident à garder le contrôle de vos échanges.</p></article>
        </div>
      </section>
      <section className="bottom-cta"><div><span className="eyebrow">VOTRE PROCHAINE HISTOIRE</span><h2>Et si tout commençait aujourd’hui ?</h2></div><Link className="button light" href="/inscription">Je crée mon profil <ArrowRight size={18}/></Link></section>
      <footer><Link className="brand footer-brand" href="/"><span className="brand-mark"><Heart size={18} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link><p>© {new Date().getFullYear()} Rencontre & Amitié · 18+ uniquement</p><div><Link href="/confidentialite">Confidentialité</Link><Link href="/conditions">Conditions</Link></div></footer>
    </main>
  );
}
