import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, Heart } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import DeleteAccountButton from "./delete-account-button";
export default async function AccountPage() {
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect("/connexion");
 return <main className="auth-shell"><Link className="back-link" href="/membres"><ArrowLeft size={16}/> Retour aux membres</Link><div className="auth-card"><Link href="/" className="brand auth-brand"><span className="brand-mark"><Heart size={20} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link><span className="eyebrow">GESTION DES DONNÉES</span><h1>Mon compte</h1><p className="auth-intro">Connecté·e avec {user.email}. Vous pouvez demander la suppression de votre compte et des données associées.</p><div className="form-notice"><Link href="/verification-identite">Vérifier mon identité</Link> — une étape facultative jusqu’à activation des règles de confiance du site.</div><div className="danger-zone"><h2>Supprimer mon compte</h2><p>Cette action est irréversible. Elle supprime le compte d’authentification et les données liées selon les règles de la base. Certaines données peuvent devoir être conservées lorsque la loi l’exige.</p><DeleteAccountButton/></div></div></main>;
}
