"use client";
import { useState } from "react";
export default function DeleteAccountButton(){
 const [busy,setBusy]=useState(false);const [error,setError]=useState("");
 async function remove(){
  if(!confirm("Supprimer définitivement votre compte ? Cette action est irréversible."))return;
  setBusy(true);setError("");
  const response=await fetch("/api/account/delete",{method:"POST"});
  if(response.ok){window.location.href="/?accountDeleted=1";return;}
  const data=await response.json().catch(()=>({}));setError(data.error||"Suppression impossible. Contactez le support.");setBusy(false);
 }
 return <><button className="button danger" onClick={remove} disabled={busy}>{busy?"Suppression…":"Supprimer définitivement mon compte"}</button>{error&&<p className="form-error">{error}</p>}</>;
}
