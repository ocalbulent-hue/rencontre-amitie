"use client";
import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Heart, ArrowLeft, LoaderCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export default function AuthForm({ mode }: { mode: "signup" | "login" }) {
  const supabase = createClient();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const signup = mode === "signup";
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setError(""); setNotice(""); setLoading(true);
    const form = new FormData(e.currentTarget);
    const email = String(form.get("email") || "").trim();
    const password = String(form.get("password") || "");
    if (signup) {
      const birthDate = String(form.get("birth_date") || "");
      const gender = String(form.get("gender") || "");
      const displayName = String(form.get("display_name") || "").trim();
      const consent = form.get("consent") === "on";
      const age = birthDate ? (Date.now() - new Date(birthDate).getTime()) / 31557600000 : 0;
      if (age < 18) { setError("L’inscription est réservée aux personnes âgées de 18 ans ou plus."); setLoading(false); return; }
      if (!consent) { setError("Vous devez accepter les conditions et la politique de confidentialité."); setLoading(false); return; }
      const { error: authError } = await supabase.auth.signUp({
        email, password,
        options: { emailRedirectTo: `${window.location.origin}/auth/callback`, data: { display_name: displayName, birth_date: birthDate, gender } }
      });
      if (authError) setError(authError.message);
      else setNotice("Compte créé. Consultez votre boîte e-mail pour confirmer votre adresse avant de vous connecter.");
    } else {
      const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
      if (authError) setError("Connexion impossible. Vérifiez votre adresse e-mail et votre mot de passe.");
      else { router.push("/membres"); router.refresh(); }
    }
    setLoading(false);
  }
  return <main className="auth-shell"><Link href="/" className="back-link"><ArrowLeft size={16}/> Retour à l’accueil</Link><div className="auth-card">
    <Link href="/" className="brand auth-brand"><span className="brand-mark"><Heart size={20} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link>
    <span className="eyebrow">{signup ? "LE DÉBUT D’UNE BELLE HISTOIRE" : "HEUREUX DE VOUS REVOIR"}</span>
    <h1>{signup ? "Créez votre profil" : "Connectez-vous"}</h1><p className="auth-intro">{signup ? "Quelques informations pour commencer à faire connaissance." : "Retrouvez votre espace et poursuivez vos conversations."}</p>
    <form onSubmit={submit}>
      {signup && <><label>Votre prénom ou pseudo<input name="display_name" required minLength={2} maxLength={40} placeholder="Ex. Camille" autoComplete="nickname"/></label>
      <div className="form-row"><label>Date de naissance<input name="birth_date" type="date" required max={new Date(Date.now()-18*365.25*86400000).toISOString().slice(0,10)}/></label>
      <label>Je suis<select name="gender" required defaultValue=""><option value="" disabled>Choisir…</option><option value="woman">Une femme</option><option value="man">Un homme</option><option value="nonbinary">Non-binaire</option><option value="prefer_not_to_say">Je préfère ne pas préciser</option></select></label></div></>}
      <label>Adresse e-mail<input name="email" type="email" required autoComplete="email" placeholder="vous@exemple.fr"/></label>
      <label>Mot de passe<input name="password" type="password" required minLength={8} autoComplete={signup ? "new-password" : "current-password"} placeholder="8 caractères minimum"/></label>
      {signup && <label className="consent"><input type="checkbox" name="consent" required/><span>J’ai 18 ans ou plus et j’accepte les <Link href="/conditions">conditions d’utilisation</Link> et la <Link href="/confidentialite">politique de confidentialité</Link>.</span></label>}
      {error && <p className="form-error" role="alert">{error}</p>}{notice && <p className="form-notice" role="status">{notice}</p>}
      <button className="button primary full" disabled={loading}>{loading ? <LoaderCircle className="spin" size={18}/> : null}{signup ? "Créer mon compte" : "Se connecter"}</button>
    </form>
    <p className="auth-switch">{signup ? "Vous avez déjà un compte ?" : "Pas encore inscrit·e ?"} <Link href={signup ? "/connexion" : "/inscription"}>{signup ? "Se connecter" : "Créer un profil"}</Link></p>
  </div><p className="auth-foot">Rencontre & Amitié · Un espace réservé aux adultes</p></main>;
}
