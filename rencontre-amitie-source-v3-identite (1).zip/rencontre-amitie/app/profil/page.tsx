import Link from "next/link";
import { redirect } from "next/navigation";
import { Heart, ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import ProfileForm from "./profile-form";
export default async function ProfilePage() {
 const supabase = await createClient(); const { data: { user } } = await supabase.auth.getUser();
 if (!user) redirect("/connexion");
 const { data: profile } = await supabase.from("profiles").select("*").eq("id",user.id).maybeSingle();
 return <main className="auth-shell"><Link className="back-link" href="/membres"><ArrowLeft size={16}/> Retour aux membres</Link><div className="auth-card profile-card"><Link href="/" className="brand auth-brand"><span className="brand-mark"><Heart size={20} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link><span className="eyebrow">VOTRE ESPACE PERSONNEL</span><h1>Votre profil</h1><p className="auth-intro">Présentez-vous avec les informations que vous souhaitez partager.</p><ProfileForm initial={profile} email={user.email || ""}/></div></main>;
}
