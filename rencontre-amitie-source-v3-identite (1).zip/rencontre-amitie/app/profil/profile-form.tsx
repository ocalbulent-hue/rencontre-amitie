"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
type Profile = { display_name?: string|null; bio?: string|null; city?: string|null; interests?: string[]|null; is_visible?: boolean|null } | null;
export default function ProfileForm({initial,email}:{initial:Profile,email:string}) {
 const [notice,setNotice]=useState(""); const [error,setError]=useState(""); const [busy,setBusy]=useState(false); const router=useRouter();
 async function submit(e:FormEvent<HTMLFormElement>) {
  e.preventDefault();setBusy(true);setError("");setNotice("");const f=new FormData(e.currentTarget);
  const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();
  if(!user){setError("Votre session a expiré. Reconnectez-vous.");setBusy(false);return;}
  const interests=String(f.get("interests")||"").split(",").map(s=>s.trim()).filter(Boolean).slice(0,10);
  const {error:err}=await supabase.from("profiles").upsert({id:user.id,email,display_name:String(f.get("display_name")).trim(),bio:String(f.get("bio")).trim(),city:String(f.get("city")).trim(),interests,is_visible:f.get("is_visible")==="on",updated_at:new Date().toISOString()});
  if(err)setError("Enregistrement impossible. Vérifiez la configuration de la base de données et réessayez.");
  else {setNotice("Votre profil a été enregistré.");router.refresh();}
  setBusy(false);
 }
 return <form onSubmit={submit}><label>Prénom ou pseudo<input name="display_name" required minLength={2} maxLength={40} defaultValue={initial?.display_name||""}/></label><label>Ville<input name="city" maxLength={80} defaultValue={initial?.city||""} placeholder="Ex. Lyon"/></label><label>Quelques mots sur vous<textarea name="bio" maxLength={500} rows={4} defaultValue={initial?.bio||""} placeholder="Vos envies, vos passions, ce qui vous fait sourire…"/></label><label>Centres d’intérêt<input name="interests" defaultValue={initial?.interests?.join(", ")||""} placeholder="Cinéma, randonnée, cuisine"/></label><label className="consent"><input type="checkbox" name="is_visible" defaultChecked={initial?.is_visible ?? true}/><span>Mon profil peut apparaître dans l’annuaire des membres.</span></label>{error&&<p className="form-error">{error}</p>}{notice&&<p className="form-notice">{notice}</p>}<button className="button primary full" disabled={busy}>{busy?"Enregistrement…":"Enregistrer mon profil"}</button></form>;
}
