import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, Heart, ShieldCheck } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import IdentityAction from "./identity-action";

export default async function IdentityPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/connexion");
  const { data } = await supabase.from("identity_verifications").select("status,verified_at").eq("user_id", user.id).maybeSingle();
  const status = data?.status || "unverified";
  const labels: Record<string,string> = {
    unverified: "Non vérifiée", pending: "En attente", verified: "Vérifiée",
    requires_input: "Informations supplémentaires requises", canceled: "Annulée"
  };
  return <main className="auth-shell">
    <Link className="back-link" href="/compte"><ArrowLeft size={16}/> Retour au compte</Link>
    <div className="auth-card">
      <Link href="/" className="brand auth-brand"><span className="brand-mark"><Heart size={20} fill="currentColor"/></span> Rencontre <em>&</em> Amitié</Link>
      <span className="eyebrow">SÉCURITÉ DU COMPTE</span>
      <h1>Vérification d’identité</h1>
      <p className="auth-intro">La vérification est réalisée par Stripe Identity. Vous serez redirigé vers son interface sécurisée pour présenter un document accepté et, si demandé, effectuer un selfie.</p>
      <div className="form-notice"><ShieldCheck size={18}/> Statut actuel : <strong>{labels[status] || status}</strong></div>
      <IdentityAction status={status}/>
      <h2>Vos données</h2>
      <p className="auth-intro">Le site ne reçoit pas et ne stocke pas de copie de votre pièce d’identité. Il conserve le statut, la date de vérification et l’identifiant technique de la session. Le prestataire traite les documents selon ses propres conditions et règles de conservation : consultez-les avant de continuer.</p>
      <p className="auth-intro">La vérification d’identité ne remplace pas la modération, le signalement des profils, ni la prudence lors des rencontres. Elle ne garantit pas à elle seule la sincérité des informations d’un membre.</p>
      <p><Link href="/confidentialite">Lire la politique de confidentialité</Link></p>
    </div>
  </main>;
}
