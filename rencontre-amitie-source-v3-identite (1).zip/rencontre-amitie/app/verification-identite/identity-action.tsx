"use client";
import { useState } from "react";

export default function IdentityAction({ status }: { status: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function start() {
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/identity/start", { method: "POST" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Une erreur est survenue.");
      window.location.assign(data.url);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Une erreur est survenue.");
      setBusy(false);
    }
  }
  if (status === "verified") return <div className="form-notice">Identité vérifiée. La plateforme conserve uniquement le statut de vérification et la référence technique.</div>;
  return <div className="form-stack">
    <button className="primary-button" onClick={start} disabled={busy}>{busy ? "Préparation…" : status === "pending" ? "Reprendre la vérification" : "Vérifier mon identité"}</button>
    {error && <p role="alert" className="form-error">{error}</p>}
  </div>;
}
